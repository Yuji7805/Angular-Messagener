import { Component } from '@angular/core';

@Component({
  selector: 'app-main-messenger-chatbox-container',
  templateUrl: './main-messenger-chatbox-container.component.html',
  styleUrls: ['./main-messenger-chatbox-container.component.scss']
})
export class MainMessengerChatboxContainerComponent {

}
